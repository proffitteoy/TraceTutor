import { isUsingEnvironmentKey } from "@/lib/envs"
import { EnvKey } from "@/types/key-type"
import { VALID_ENV_KEYS } from "@/types/valid-keys"

const ENV_KEY_MAP: Record<string, EnvKey> = {
  azure: VALID_ENV_KEYS.AZURE_OPENAI_API_KEY,
  openai: VALID_ENV_KEYS.OPENAI_API_KEY,
  google: VALID_ENV_KEYS.GOOGLE_GEMINI_API_KEY,
  anthropic: VALID_ENV_KEYS.ANTHROPIC_API_KEY,
  mistral: VALID_ENV_KEYS.MISTRAL_API_KEY,
  groq: VALID_ENV_KEYS.GROQ_API_KEY,
  perplexity: VALID_ENV_KEYS.PERPLEXITY_API_KEY,
  deepseek: VALID_ENV_KEYS.DEEPSEEK_API_KEY,
  openrouter: VALID_ENV_KEYS.OPENROUTER_API_KEY,
  gptsapi: VALID_ENV_KEYS.GPTSAPI_API_KEY,
  openai_organization_id: VALID_ENV_KEYS.OPENAI_ORGANIZATION_ID,
  azure_openai_endpoint: VALID_ENV_KEYS.AZURE_OPENAI_ENDPOINT,
  azure_gpt_35_turbo_name: VALID_ENV_KEYS.AZURE_GPT_35_TURBO_NAME,
  azure_gpt_45_vision_name: VALID_ENV_KEYS.AZURE_GPT_45_VISION_NAME,
  azure_gpt_45_turbo_name: VALID_ENV_KEYS.AZURE_GPT_45_TURBO_NAME,
  azure_embeddings_name: VALID_ENV_KEYS.AZURE_EMBEDDINGS_NAME
}

export const getEnvironmentKeyMap = () =>
  Object.entries(ENV_KEY_MAP).reduce<Record<string, boolean>>(
    (result, [provider, key]) => {
      result[provider] = isUsingEnvironmentKey(key)
      return result
    },
    {}
  )
